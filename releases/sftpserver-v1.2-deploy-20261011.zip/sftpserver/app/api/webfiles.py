"""用户侧 HTTPS Web 文件访问（加密目录路径 /f/{token}/）"""
import os
from datetime import datetime, date

from fastapi import APIRouter, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse

from .. import security, state
from ..audit import audit
from ..config import load_secret
from ..db import SessionLocal
from ..models import SftpUser
from ..vfs import PathEscape, resolve

router = APIRouter()

WEB_COOKIE = "websess"


def _auth_user(request: Request, token: str) -> SftpUser:
    """三重校验（不泄露存在性）：
    1. token 必须命中某账号的当前加密路径，否则 404（含已轮换/禁用场景）
    2. 必须已登录 Web 会话，否则 404（避免向未认证者泄露 token 有效性）
    3. 会话用户必须等于 token 属主，否则 404（拿他人 token 同样 404）
    """
    username = security.web_get(request.cookies.get(WEB_COOKIE, ""))
    with SessionLocal() as s:
        u = s.query(SftpUser).filter_by(web_token=token, deleted_at=None).first()
        if not u or not u.enabled or not u.web_enabled:
            raise HTTPException(404, "Not Found")
        if not username or username != u.username:
            raise HTTPException(404, "Not Found")
        s.expunge(u)
        return u


def _check(u: SftpUser, need: str):
    if need == "read" and not u.perm_read:
        raise HTTPException(403, "无读取权限")
    if need == "write" and not u.perm_write:
        raise HTTPException(403, "无写入权限")
    if need == "delete" and not u.perm_delete:
        raise HTTPException(403, "无删除权限")
    if need == "rename" and not u.perm_rename:
        raise HTTPException(403, "无改名权限")


@router.get("/web/login")
def web_login_page():
    """浏览器登录页（人工测试用）：登录成功后跳转到本人加密路径"""
    return HTMLResponse(
        """<!doctype html><html lang="zh"><head><meta charset="utf-8">
<title>SFTP Web 登录</title><style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
background:#f5f5f7;font-family:"Noto Sans SC","Microsoft YaHei",sans-serif}
.card{background:#fff;border-radius:16px;padding:40px 36px;width:320px;
box-shadow:0 8px 30px rgba(11,61,98,.12)}
h1{margin:0 0 6px;font-size:20px;color:#0b3d62;font-family:"Noto Serif SC",serif}
p{margin:0 0 22px;font-size:12px;color:#889}
input{width:100%;box-sizing:border-box;padding:11px 12px;margin-bottom:12px;
border:1px solid #d8dde3;border-radius:10px;font-size:14px;outline:none}
input:focus{border-color:#0b3d62}
button{width:100%;padding:12px;border:0;border-radius:10px;background:#0b3d62;
color:#fff;font-size:15px;cursor:pointer}
button:disabled{opacity:.6}
#msg{margin-top:14px;font-size:13px;color:#c0392b;min-height:18px}
</style></head><body><div class="card">
<h1>文件访问登录</h1><p>登录后进入你的加密目录路径</p>
<input id="u" placeholder="用户名" autofocus>
<input id="p" type="password" placeholder="密码" onkeydown="if(event.key==='Enter')doLogin()">
<button id="b" onclick="doLogin()">登 录</button>
<div id="msg"></div></div>
<script>
async function doLogin(){
  const b=document.getElementById('b'),m=document.getElementById('msg');
  b.disabled=true;m.textContent='';m.style.color='#c0392b';
  try{
    const r=await fetch('/web/login',{method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({username:u.value.trim(),password:p.value})});
    if(!r.ok){const t=await r.text();m.textContent=t.replace(/<[^>]+>/g,'').slice(0,80)||('HTTP '+r.status);return;}
    const h=await r.text();
    const tok=(h.match(/\\/f\\/([A-Za-z0-9]+)\\//)||[])[1];
    if(tok){location.href='/f/'+tok+'/';}else{m.textContent='登录成功但未获取到路径';}
  }catch(e){m.textContent='网络错误：'+e;}
  finally{b.disabled=false;}
}
</script></body></html>""")


@router.post("/web/login")
def web_login(body: dict, request: Request):
    username = (body.get("username") or "").strip().lower()
    password = body.get("password") or ""
    ip = request.client.host if request.client else ""
    if state.is_locked(username):
        audit("web", username, "login", "账号锁定中", ip, result="deny")
        raise HTTPException(423, "账号已锁定，请稍后再试")
    with SessionLocal() as s:
        u = s.query(SftpUser).filter_by(username=username, deleted_at=None).first()
        expired = bool(u and u.expires_at and
                       (u.expires_at if isinstance(u.expires_at, datetime) else
                        datetime.strptime(str(u.expires_at), "%Y-%m-%d %H:%M:%S")) <= datetime.utcnow())
        if not (u and u.enabled and u.web_enabled and not expired
                and security.verify_password(password, u.password_hash)):
            state.record_fail(username)
            audit("web", username, "login", "认证失败（统一提示，不区分原因）", ip, result="deny")
            raise HTTPException(401, "认证失败")
        state.clear_fails(username)
        token = security.make_admin_token()
        security.web_login(token, username)
        audit("web", username, "login", "Web 登录成功", ip)
        resp = HTMLResponse(
            f"<h3>登录成功</h3><p>你的加密目录路径：</p>"
            f"<p><code>/f/{u.web_token}/</code></p>"
            f'<p><a href="/f/{u.web_token}/">进入文件列表</a></p>')
        resp.set_cookie(WEB_COOKIE, token, httponly=True, samesite="lax")
        return resp


@router.get("/f/{token}/")
def web_index(token: str, request: Request):
    u = _auth_user(request, token)
    return _list_html(u, token, "/")


def _list_html(u: SftpUser, token: str, path: str) -> HTMLResponse:
    rows = []
    try:
        real, rel = resolve(u.root_dir, path)
    except PathEscape:
        raise HTTPException(403, "路径越界")
    for name in sorted(os.listdir(real)) if os.path.isdir(real) else []:
        full = os.path.join(real, name)
        rel_path = "/" + (rel + "/" + name if rel else name)
        if os.path.isdir(full):
            rows.append(f'<tr><td>📁 <a href="/f/{token}/?path={rel_path}">{name}</a></td><td>—</td></tr>')
        else:
            rows.append(f'<tr><td>📄 {name}</td><td>{os.path.getsize(full):,} B</td>'
                        f'<td><a href="/f/{token}/download?path={rel_path}">下载</a></td></tr>')
    body = "".join(rows) or "<tr><td colspan=3>空目录</td></tr>"
    return HTMLResponse(
        f"<h3>文件列表（加密路径 /f/{token}/）</h3>"
        f"<p>当前路径: {path}</p>"
        f"<table border=1 cellpadding=4>{body}</table>")


@router.get("/f/{token}/api/list")
def web_list(token: str, request: Request, path: str = "/"):
    u = _auth_user(request, token)
    _check(u, "read")
    try:
        real, rel = resolve(u.root_dir, path)
    except PathEscape:
        audit("web", u.username, "deny", f"路径越界 {path}", "", result="deny")
        raise HTTPException(403, "路径越界")
    if not os.path.isdir(real):
        raise HTTPException(404, "目录不存在")
    items = []
    for name in sorted(os.listdir(real)):
        full = os.path.join(real, name)
        rel_path = "/" + (rel + "/" + name if rel else name)
        st = os.stat(full)
        items.append({"name": name, "path": rel_path,
                      "is_dir": os.path.isdir(full), "size": st.st_size})
    audit("web", u.username, "list", f"目录列表 {rel}")
    return {"path": rel, "items": items}


@router.get("/f/{token}/download")
def web_download(token: str, request: Request, path: str):
    u = _auth_user(request, token)
    _check(u, "read")
    try:
        real, rel = resolve(u.root_dir, path)
    except PathEscape:
        audit("web", u.username, "deny", f"下载越界 {path}", "", result="deny")
        raise HTTPException(403, "路径越界")
    if os.path.isdir(real) or not os.path.exists(real):
        raise HTTPException(404, "文件不存在")
    audit("web", u.username, "download", f"/{rel} ({os.path.getsize(real):,} B)")
    return FileResponse(real, filename=os.path.basename(real))


@router.post("/f/{token}/upload")
async def web_upload(token: str, request: Request, file: UploadFile, path: str = "/"):
    u = _auth_user(request, token)
    _check(u, "write")
    try:
        real, rel = resolve(u.root_dir, path)
    except PathEscape:
        raise HTTPException(403, "路径越界")
    if not os.path.isdir(real):
        raise HTTPException(404, "目标目录不存在")
    dest = os.path.join(real, os.path.basename(file.filename))
    # 覆盖写账目：旧文件尺寸冲抵，文件数不重复计
    overwrite = os.path.isfile(dest)
    old_size = os.path.getsize(dest) if overwrite else 0
    base_used = (u.used_bytes or 0) - old_size
    # 配额预检（L1）
    if u.max_file_size and file.size and file.size > u.max_file_size:
        raise HTTPException(413, "超过单文件大小限制")
    if u.quota_files and not overwrite and ((u.used_files or 0) + 1) > u.quota_files:
        audit("web", u.username, "quota_deny", f"上传 {file.filename} 超文件数配额", "", result="deny")
        raise HTTPException(507, "超出文件数配额")
    if u.quota_bytes and (base_used + (file.size or 0)) > u.quota_bytes:
        audit("web", u.username, "quota_deny", f"上传 {file.filename} 超配额", "", result="deny")
        raise HTTPException(507, "超出空间配额")
    written = 0
    with open(dest, "wb") as out:
        while chunk := await file.read(1024 * 512):
            written += len(chunk)
            if u.quota_bytes and (base_used + written) > u.quota_bytes:
                out.close()
                os.remove(dest)
                audit("web", u.username, "quota_deny",
                      f"上传 {file.filename} 传输中超配额，已回滚", "", result="deny")
                raise HTTPException(507, "超出空间配额")
            out.write(chunk)
    with SessionLocal() as s:
        s.query(SftpUser).filter_by(id=u.id).update({
            "used_bytes": base_used + written,
            "used_files": (u.used_files or 0) + (0 if overwrite else 1),
        })
        s.commit()
    vpath = "/" + (f"{rel}/{os.path.basename(file.filename)}" if rel else os.path.basename(file.filename))
    audit("web", u.username, "upload", f"{vpath} ({written:,} B)")
    return {"ok": True, "size": written}


@router.post("/f/{token}/delete")
def web_delete(token: str, request: Request, path: str):
    u = _auth_user(request, token)
    _check(u, "delete")
    try:
        real, rel = resolve(u.root_dir, path)
    except PathEscape:
        raise HTTPException(403, "路径越界")
    if real == os.path.realpath(u.root_dir):
        raise HTTPException(403, "不能删除根目录")
    if not os.path.exists(real):
        raise HTTPException(404, "文件或目录不存在")
    is_dir = os.path.isdir(real)
    size = 0 if is_dir else os.path.getsize(real)
    try:
        if is_dir:
            os.rmdir(real)
        else:
            os.remove(real)
    except OSError as e:
        win_notempty = getattr(e, "winerror", None) == 145
        if isinstance(e, FileNotFoundError) or win_notempty:
            raise HTTPException(404 if isinstance(e, FileNotFoundError) else 409,
                                "目录不存在" if isinstance(e, FileNotFoundError) else "目录非空")
        raise HTTPException(500, "删除失败")
    # 同步扣减用量（文件数/字节数），避免账目漂移
    if not is_dir:
        with SessionLocal() as s:
            s.query(SftpUser).filter_by(id=u.id).update({
                "used_bytes": (u.used_bytes or 0) - size,
                "used_files": (u.used_files or 0) - 1,
            })
            s.commit()
    audit("web", u.username, "delete", "/" + rel if rel else "/")
    return {"ok": True}


@router.post("/f/{token}/rename")
def web_rename(token: str, request: Request, path: str, to: str):
    """Web 改名（PRD §3.3 W：列表/下载/上传/删除/改名）"""
    u = _auth_user(request, token)
    _check(u, "rename")
    try:
        real, rel = resolve(u.root_dir, path)
        new_real, new_rel = resolve(u.root_dir, to)
    except PathEscape:
        audit("web", u.username, "deny", f"改名越界 {path} -> {to}", "", result="deny")
        raise HTTPException(403, "路径越界")
    if not rel:
        raise HTTPException(403, "不能重命名根目录")
    if not os.path.exists(real):
        raise HTTPException(404, "文件或目录不存在")
    if os.path.exists(new_real):
        raise HTTPException(409, "目标名称已存在")
    os.rename(real, new_real)
    audit("web", u.username, "rename", f"/{rel} -> /{new_rel}")
    return {"ok": True, "path": "/" + new_rel}


@router.post("/web/logout")
def web_logout(request: Request):
    security.web_logout(request.cookies.get(WEB_COOKIE, ""))
    resp = HTMLResponse("已退出")
    resp.delete_cookie(WEB_COOKIE)
    return resp

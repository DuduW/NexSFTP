from fastapi import APIRouter, HTTPException, Request

from .. import security, state
from ..audit import audit, recalc_usage
from ..config import FILE_ROOT, load_secret
from ..db import SessionLocal
from ..models import Admin, AuditLog, SftpUser

router = APIRouter(prefix="/api/v1")


def require_admin(request: Request):
    auth = request.headers.get("Authorization", "")
    token = auth[7:] if auth.startswith("Bearer ") else ""
    if not security.admin_login(token):
        raise HTTPException(401, "未登录或会话过期")
    return token


def _user_dict(u: SftpUser, mask: bool = True) -> dict:
    d = {
        "id": u.id, "username": u.username, "root_dir": u.root_dir,
        "perm_read": u.perm_read, "perm_write": u.perm_write,
        "perm_delete": u.perm_delete, "perm_rename": u.perm_rename,
        "quota_bytes": u.quota_bytes, "quota_files": u.quota_files,
        "max_file_size": u.max_file_size,
        "enabled": u.enabled, "expires_at": u.expires_at.isoformat() if u.expires_at else None,
        "web_enabled": u.web_enabled, "web_token": u.web_token,
        "used_bytes": u.used_bytes, "used_files": u.used_files,
        "remark": u.remark,
        "created_at": u.created_at.isoformat() if u.created_at else None,
    }
    return d


def get_valid_user(s, username: str) -> SftpUser:
    u = s.query(SftpUser).filter_by(username=username, deleted_at=None).first()
    return u


@router.post("/auth/login")
def admin_login(body: dict, request: Request):
    username = (body.get("username") or "").strip()
    password = body.get("password") or ""
    with SessionLocal() as s:
        a = s.query(Admin).filter_by(username=username, enabled=True).first()
        if a and security.verify_password(password, a.password_hash):
            token = security.make_admin_token()
            security.admin_session_create(token)
            a.last_login_at = security.utcnow()
            s.commit()
            audit("admin", username, "login", "管理员登录成功",
                  request.client.host if request.client else "")
            return {"token": token}
    audit("admin", username, "login", "管理员登录失败",
          request.client.host if request.client else "", result="deny")
    raise HTTPException(401, "认证失败")


@router.post("/auth/logout")
def admin_logout(request: Request):
    security.admin_logout(require_admin(request))
    return {"ok": True}


@router.get("/dashboard/summary")
def dashboard(request: Request):
    require_admin(request)
    with SessionLocal() as s:
        users = s.query(SftpUser).filter_by(deleted_at=None).all()
        logs_today = s.query(AuditLog).filter(
            AuditLog.ts >= security.utcnow().replace(hour=0, minute=0, second=0)).count()
        top = sorted(users, key=lambda u: -(u.used_bytes or 0))[:5]
        return {
            "accounts_total": len(users),
            "accounts_enabled": sum(1 for u in users if u.enabled),
            "sessions_online": len(state.sftp_sessions),
            "audit_today": logs_today,
            "disk_top": [{"username": u.username, "used_bytes": u.used_bytes,
                          "quota_bytes": u.quota_bytes} for u in top],
        }


@router.get("/dashboard/trend")
def dashboard_trend(request: Request):
    """近 7 日上传/下载字节量趋势（按审计日志 detail 中的 '(N B)' 解析）"""
    require_admin(request)
    import re
    from datetime import datetime, timedelta
    now = security.utcnow()
    days = [(now - timedelta(days=i)).date() for i in range(6, -1, -1)]
    start = datetime.combine(days[0], datetime.min.time())
    up = {d: 0 for d in days}
    down = {d: 0 for d in days}
    with SessionLocal() as s:
        rows = s.query(AuditLog).filter(
            AuditLog.ts >= start,
            AuditLog.action.in_(["upload", "download"]),
            AuditLog.result != "deny").all()
    pat = re.compile(r"\(([\d,]+) B\)")
    for r in rows:
        m = pat.search(r.detail or "")
        if not m:
            continue
        size = int(m.group(1).replace(",", ""))
        d = r.ts.date()
        if d in up:
            (up if r.action == "upload" else down)[d] += size
    return {"items": [{"date": d.isoformat(), "up": up[d], "down": down[d]} for d in days]}


@router.get("/users")
def list_users(request: Request, q: str = ""):
    require_admin(request)
    with SessionLocal() as s:
        query = s.query(SftpUser).filter_by(deleted_at=None)
        if q:
            query = query.filter(SftpUser.username.contains(q))
        return [_user_dict(u) for u in query.order_by(SftpUser.id).all()]


@router.post("/users", status_code=201)
def create_user(body: dict, request: Request):
    admin = require_admin(request)
    username = (body.get("username") or "").strip().lower()
    password = body.get("password") or ""
    import re
    if not re.fullmatch(r"[a-z0-9_]{2,32}", username):
        raise HTTPException(400, "用户名仅限小写字母/数字/下划线，2-32 位")
    if len(password) < 8 or not (any(c.isdigit() for c in password) and any(c.isalpha() for c in password)):
        raise HTTPException(400, "密码须≥8位且含字母和数字")
    with SessionLocal() as s:
        if s.query(SftpUser).filter_by(username=username).first():
            raise HTTPException(400, "用户名已存在")
        root = FILE_ROOT
        import os
        user_dir = os.path.join(FILE_ROOT, username)
        os.makedirs(user_dir, exist_ok=True)
        salt = security.new_salt()
        u = SftpUser(
            username=username,
            password_hash=security.hash_password(password),
            root_dir=user_dir,
            perm_read=body.get("perm_read", True),
            perm_write=body.get("perm_write", True),
            perm_delete=body.get("perm_delete", False),
            perm_rename=body.get("perm_rename", False),
            quota_bytes=int(body.get("quota_bytes", 10 * 1024 ** 3)),
            quota_files=int(body.get("quota_files", 0)),
            max_file_size=int(body.get("max_file_size", 0)),
            web_enabled=body.get("web_enabled", True),
            rate_up=int(body.get("rate_up", 0)),
            rate_down=int(body.get("rate_down", 0)),
            max_sessions=int(body.get("max_sessions", 0)),
            web_salt=salt,
            web_token=security.gen_web_token(username, salt, load_secret()),
            web_token_at=security.utcnow(),
            remark=body.get("remark", ""),
        )
        s.add(u)
        s.commit()
        audit("admin", admin, "manage", f"创建账号 {username}",
              request.client.host if request.client else "")
        return _user_dict(u)


@router.patch("/users/{user_id}")
def update_user(user_id: int, body: dict, request: Request):
    """编辑账号：权限四开关 / 配额 / 单文件上限 / 有效期 / Web 开关 / 备注"""
    admin = require_admin(request)
    fields = {
        "perm_read": bool, "perm_write": bool, "perm_delete": bool,
        "perm_rename": bool, "web_enabled": bool,
        "quota_bytes": int, "quota_files": int, "max_file_size": int,
        "rate_up": int, "rate_down": int, "max_sessions": int,
    }
    updates = {}
    for k, typ in fields.items():
        if k in body:
            updates[k] = typ(body[k])
    if "expires_at" in body:
        updates["expires_at"] = body["expires_at"] or None  # ""/null 清除有效期
    if "remark" in body:
        updates["remark"] = str(body["remark"])[:200]
    if not updates:
        raise HTTPException(400, "无可更新字段")
    with SessionLocal() as s:
        u = s.get(SftpUser, user_id)
        if not u or u.deleted_at:
            raise HTTPException(404, "用户不存在")
        for k, v in updates.items():
            setattr(u, k, v)
        s.commit()
        audit("admin", admin, "manage", f"编辑账号 {u.username}: {', '.join(updates)}",
              request.client.host if request.client else "")
        return _user_dict(u)


@router.post("/users/{user_id}/reset-password")
def reset_password(user_id: int, body: dict, request: Request):
    admin = require_admin(request)
    password = body.get("password") or ""
    if len(password) < 8:
        raise HTTPException(400, "密码须≥8位")
    with SessionLocal() as s:
        u = s.get(SftpUser, user_id)
        if not u or u.deleted_at:
            raise HTTPException(404, "用户不存在")
        u.password_hash = security.hash_password(password)
        s.commit()
        audit("admin", admin, "manage", f"重置 {u.username} 密码",
              request.client.host if request.client else "")
        return {"ok": True}


@router.post("/users/{user_id}/toggle")
def toggle_user(user_id: int, body: dict, request: Request):
    admin = require_admin(request)
    with SessionLocal() as s:
        u = s.get(SftpUser, user_id)
        if not u or u.deleted_at:
            raise HTTPException(404, "用户不存在")
        u.enabled = bool(body.get("enabled"))
        s.commit()
        audit("admin", admin, "manage",
              f"{'启用' if u.enabled else '禁用'}账号 {u.username}",
              request.client.host if request.client else "")
        return {"ok": True, "enabled": u.enabled}


@router.delete("/users/{user_id}")
def delete_user(user_id: int, request: Request):
    admin = require_admin(request)
    with SessionLocal() as s:
        u = s.get(SftpUser, user_id)
        if not u or u.deleted_at:
            raise HTTPException(404, "用户不存在")
        u.deleted_at = security.utcnow()
        u.enabled = False
        u.web_enabled = False
        s.commit()
        audit("admin", admin, "manage", f"删除账号 {u.username}",
              request.client.host if request.client else "")
        return {"ok": True}


@router.post("/users/{user_id}/usage")
def refresh_usage(user_id: int, request: Request):
    require_admin(request)
    with SessionLocal() as s:
        u = s.get(SftpUser, user_id)
        if not u or u.deleted_at:
            raise HTTPException(404, "用户不存在")
        used_bytes, used_files = recalc_usage(u.root_dir)
        u.used_bytes, u.used_files = used_bytes, used_files
        s.commit()
        return {"used_bytes": used_bytes, "used_files": used_files}


@router.post("/users/{user_id}/regen-web-token")
def regen_web_token(user_id: int, request: Request):
    admin = require_admin(request)
    from ..config import load_secret
    with SessionLocal() as s:
        u = s.get(SftpUser, user_id)
        if not u or u.deleted_at:
            raise HTTPException(404, "用户不存在")
        u.web_salt = security.new_salt()
        u.web_token = security.gen_web_token(u.username, u.web_salt, load_secret())
        u.web_token_at = security.utcnow()
        s.commit()
        audit("admin", admin, "manage", f"轮换 {u.username} 加密路径（旧路径失效）",
              request.client.host if request.client else "")
        return {"web_token": u.web_token}


@router.get("/sessions")
def list_sessions(request: Request):
    require_admin(request)
    with state._lock:
        return [{"sid": sid, "username": v["username"], "ip": v["ip"],
                 "login_at": v["login_at"]}
                for sid, v in state.sftp_sessions.items()]


@router.delete("/sessions/{sid}")
def kick_session(sid: str, request: Request):
    admin = require_admin(request)
    with state._lock:
        sess = state.sftp_sessions.get(sid)
    if not sess:
        raise HTTPException(404, "会话不存在或已断开")
    try:
        sess["conn"].close()
    except Exception:
        pass
    audit("admin", admin, "manage", f"强制断开会话 {sess['username']}", "")
    return {"ok": True}


@router.get("/logs")
def list_logs(request: Request, username: str = "", action: str = "",
              page: int = 1, size: int = 50):
    require_admin(request)
    with SessionLocal() as s:
        query = s.query(AuditLog)
        if username:
            query = query.filter(AuditLog.username == username)
        if action:
            query = query.filter(AuditLog.action == action)
        total = query.count()
        rows = query.order_by(AuditLog.id.desc()).offset((page - 1) * size).limit(size).all()
        return {"total": total, "items": [{
            "id": r.id, "ts": r.ts.isoformat(), "src": r.src, "username": r.username,
            "action": r.action, "detail": r.detail, "client_ip": r.client_ip,
            "result": r.result} for r in rows]}

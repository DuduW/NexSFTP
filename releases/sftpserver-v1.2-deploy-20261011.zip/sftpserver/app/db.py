from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from . import config

engine = create_engine(f"sqlite:///{config.DB_PATH}", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


def init_db():
    from . import models  # noqa: F401
    config.ensure_dirs()
    Base.metadata.create_all(engine)
    # 轻量迁移：为旧库补齐新增列（SQLite ALTER TABLE ADD COLUMN）
    import sqlalchemy
    with engine.connect() as conn:
        cols = {r[1] for r in conn.exec_driver_sql("PRAGMA table_info(sftp_users)")}
        for name, ddl in [
            ("rate_up", "BIGINT DEFAULT 0"),
            ("rate_down", "BIGINT DEFAULT 0"),
            ("max_sessions", "INTEGER DEFAULT 0"),
        ]:
            if name not in cols:
                conn.exec_driver_sql(f"ALTER TABLE sftp_users ADD COLUMN {name} {ddl}")
        conn.commit()
    from .security import hash_password
    with SessionLocal() as s:
        if not s.query(models.Admin).filter_by(username=config.DEFAULT_ADMIN_USER).first():
            s.add(models.Admin(username=config.DEFAULT_ADMIN_USER,
                                password_hash=hash_password(config.DEFAULT_ADMIN_PASS)))
            s.commit()

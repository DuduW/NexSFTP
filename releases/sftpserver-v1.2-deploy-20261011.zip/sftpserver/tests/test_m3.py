"""M3 功能验证：限速 / 并发会话数 / 文件数配额（测试账号 alice/bob）"""
import asyncio
import time

import asyncssh
import httpx

BASE = "http://127.0.0.1:8443"
c = httpx.Client(base_url=BASE, timeout=30)
H = {"Authorization": "Bearer " + c.post("/api/v1/auth/login",
     json={"username": "admin", "password": "admin1234"}).json()["token"]}

results = []


def check(name, ok, extra=""):
    results.append((name, ok))
    print(("PASS" if ok else "FAIL"), "|", name, ("| " + str(extra)) if extra else "")


# --- M3-1 限速：bob 上传限 30KB/s，传 90KB 应约 3s ---
c.patch("/api/v1/users/2", json={"rate_up": 30 * 1024}, headers=H)


async def up():
    conn = await asyncssh.connect("127.0.0.1", port=2022, username="bob",
                                  password="Bob123456", known_hosts=None)
    async with conn.start_sftp_client() as sftp:
        t0 = time.monotonic()
        async with sftp.open("/throttle.bin", "wb") as f:
            await f.write(b"x" * 90 * 1024)
        el = time.monotonic() - t0
    conn.close()
    return el


asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
el = asyncio.run(up())
check("M3-1 上传限速 90KB@30KB/s", el >= 2.5, f"耗时 {el:.1f}s")

# --- M3-2 并发会话数：bob max_sessions=1 ---
c.patch("/api/v1/users/2", json={"max_sessions": 1}, headers=H)


async def two():
    c1 = await asyncssh.connect("127.0.0.1", port=2022, username="bob",
                                password="Bob123456", known_hosts=None)
    try:
        await asyncssh.connect("127.0.0.1", port=2022, username="bob",
                               password="Bob123456", known_hosts=None)
        return False
    except asyncssh.PermissionDenied:
        return True
    finally:
        c1.close()


check("M3-2 并发会话限制 max=1（第二连接被拒）", asyncio.run(two()))
c.patch("/api/v1/users/2", json={"max_sessions": 0}, headers=H)

# --- M3-3 文件数配额：新建专用账号 quota_files=1，第2个新文件被拒 ---
import secrets

fq = "fileq" + secrets.token_hex(3)
r = c.post("/api/v1/users", json={"username": fq, "password": "Fileq1234",
                                  "quota_files": 1}, headers=H)
assert r.status_code == 201, r.text
fid = r.json()["id"]


async def fc():
    conn = await asyncssh.connect("127.0.0.1", port=2022, username=fq,
                                  password="Fileq1234", known_hosts=None)
    out = []
    async with conn.start_sftp_client() as sftp:
        for name in ("first.txt", "second.txt"):
            try:
                async with sftp.open("/" + name, "wb") as f:
                    await f.write(b"hi")
                out.append((name, "ok"))
            except asyncssh.SFTPError as e:
                out.append((name, "denied:" + type(e).__name__))
    conn.close()
    return out


out = asyncio.run(fc())
c.delete("/api/v1/users/" + str(fid), headers=H)
check("M3-3 文件数配额 quota_files=1（第2个新文件被拒）",
      out[0][1] == "ok" and out[1][1].startswith("denied"), str(out))

print("已恢复 bob: rate_up=0 / max_sessions=0 / quota_files=0")

fails = [n for n, ok in results if not ok]
print(f"\n===== M3 SUMMARY: total={len(results)} fail={len(fails)} =====")
if fails:
    print("FAILED:", fails)
    raise SystemExit(1)
print("ALL M3 TESTS PASSED")

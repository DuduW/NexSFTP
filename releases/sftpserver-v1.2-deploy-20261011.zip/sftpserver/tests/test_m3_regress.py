"""M3 补充回归：下载限速（ReadThrottle）+ 不限速读写回环（不破坏现有账号）"""
import asyncio
import time

import asyncssh
import httpx

BASE = "http://127.0.0.1:8443"
c = httpx.Client(base_url=BASE, timeout=30)
H = {"Authorization": "Bearer " + c.post("/api/v1/auth/login",
     json={"username": "admin", "password": "admin1234"}).json()["token"]}
asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

# bob 下载限速 50KB/s，下载 90KB 的 throttle.bin 应约 2s
c.patch("/api/v1/users/2", json={"rate_down": 50 * 1024}, headers=H)


async def down():
    conn = await asyncssh.connect("127.0.0.1", port=2022, username="bob",
                                  password="Bob123456", known_hosts=None)
    async with conn.start_sftp_client() as sftp:
        t0 = time.monotonic()
        async with sftp.open("/throttle.bin", "rb") as f:
            data = await f.read()
        el = time.monotonic() - t0
    conn.close()
    return el, len(data)


el, n = asyncio.run(down())
print(("PASS" if el >= 1.5 and n == 90 * 1024 else "FAIL"),
      f"| M3-4 下载限速 90KB@50KB/s 耗时 {el:.1f}s, {n}B")
c.patch("/api/v1/users/2", json={"rate_down": 0}, headers=H)

# alice（无限速）读写回环
async def rt():
    conn = await asyncssh.connect("127.0.0.1", port=2022, username="alice",
                                  password="Alice1234", known_hosts=None)
    ok = False
    async with conn.start_sftp_client() as sftp:
        data = b"regression-" * 1000
        async with sftp.open("/regress.bin", "wb") as f:
            await f.write(data)
        async with sftp.open("/regress.bin", "rb") as f:
            ok = await f.read() == data
        await sftp.remove("/regress.bin")
    conn.close()
    return ok


print(("PASS" if asyncio.run(rt()) else "FAIL"), "| M3-5 无限速读写回环")
print("M3 REGRESSION DONE")

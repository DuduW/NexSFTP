"""SFTP 服务器端到端测试（M1 验收）

覆盖：管理面 / SFTP 认证与传输 / 路径越界 / symlink 逃逸 / 权限 / 配额 /
用户隔离 / 审计 / Web 加密路径访问与轮换
"""
import asyncio
import io
import os
import sys

import asyncssh
import httpx

BASE = "http://127.0.0.1:8443"
results = []

# ---- 测试前清库（幂等，可重复运行）----
import sqlite3
_db = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "sftpserver.db")
_conn = sqlite3.connect(_db, timeout=15)
_conn.execute("DELETE FROM sftp_users")
_conn.execute("DELETE FROM audit_logs")
_conn.commit()
_conn.close()


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("PASS | " if cond else "FAIL | ") + name + (f" | {detail}" if detail else ""), flush=True)


c = httpx.Client(base_url=BASE, timeout=60)

# ================= 管理面 =================
r = c.post("/api/v1/auth/login", json={"username": "admin", "password": "admin1234"})
check("A1 管理员登录", r.status_code == 200, r.text[:80])
H = {"Authorization": "Bearer " + r.json().get("token", "")}

PERM_RW = dict(perm_read=True, perm_write=True, perm_delete=True, perm_rename=True)
for name, pw, quota, perms in [
    ("alice", "Alice1234", 5 * 1024 * 1024, PERM_RW),
    ("bob", "Bob123456", 5 * 1024 * 1024, PERM_RW),
    ("carol", "Carol1234", 5 * 1024 * 1024,
     dict(perm_read=True, perm_write=False, perm_delete=False, perm_rename=False)),
]:
    r = c.post("/api/v1/users", json={"username": name, "password": pw,
                                      "quota_bytes": quota, **perms}, headers=H)
    ok = r.status_code == 201 or (r.status_code == 400 and "已存在" in r.text)
    check(f"U1 创建账号 {name}", ok, r.text[:80])

r = c.post("/api/v1/users", json={"username": "bad1", "password": "short"}, headers=H)
check("U2 弱密码拒绝", r.status_code == 400)
r = c.post("/api/v1/users", json={"username": "a!", "password": "Abcdef12"}, headers=H)
check("U3 非法用户名拒绝", r.status_code == 400)


# ================= SFTP 传输面 =================
async def sftp_checks():
    async with asyncssh.connect("127.0.0.1", port=2022, username="alice",
                                password="Alice1234", known_hosts=None) as conn:
        async with conn.start_sftp_client() as sftp:
            data = b"hello sftp " * 5000
            async with sftp.open("/roundtrip.bin", "wb") as f:
                await f.write(data)
            async with sftp.open("/roundtrip.bin", "rb") as f:
                out = await f.read()
            check("S1 上传下载回环", out == data, f"{len(out)} B")

            await sftp.mkdir("/dir1")
            names = await sftp.listdir("/")
            check("S2 建目录+列表", "dir1" in names and "roundtrip.bin" in names, str(names))

            await sftp.rename("/roundtrip.bin", "/roundtrip2.bin")
            ok3 = "roundtrip2.bin" in (await sftp.listdir("/"))
            await sftp.rename("/roundtrip2.bin", "/roundtrip.bin")
            check("S3 改名", ok3)

            esc = False
            try:
                await sftp.stat("/../../etc/passwd")
            except asyncssh.SFTPError:
                esc = True
            check("S4 ../ 越界拦截", esc)

            esc2 = False
            try:
                await sftp.stat("..")
            except asyncssh.SFTPError:
                esc2 = True
            check("S5 相对 .. 越界拦截", esc2)

            lnk = True
            try:
                await sftp.symlink("/../../outside_target", "/evil_lnk")
            except asyncssh.SFTPError:
                lnk = False
            check("S6 symlink 逃逸拒绝", not lnk)

            big = b"x" * (6 * 1024 * 1024)
            qr = False
            try:
                async with sftp.open("/big.bin", "wb") as f:
                    await f.write(big)
            except asyncssh.SFTPError:
                qr = True
            check("S7 超配额上传被拒(5MB 配额/6MB 文件)", qr)

            d1 = True
            try:
                await sftp.remove("/roundtrip.bin")
            except asyncssh.SFTPError as e:
                d1 = False
                print("   remove err:", e)
            check("S8 删除文件", d1)

    try:
        async with asyncssh.connect("127.0.0.1", port=2022, username="carol",
                                    password="Carol1234", known_hosts=None) as conn:
            async with conn.start_sftp_client() as sftp:
                ro = False
                try:
                    async with sftp.open("/nope.bin", "wb") as f:
                        await f.write(b"x")
                except asyncssh.SFTPError:
                    ro = True
                check("S9 只读账号上传被拒", ro)
    except Exception as e:
        check("S9 只读账号上传被拒", False, str(e))

    wrong = False
    try:
        await asyncssh.connect("127.0.0.1", port=2022, username="alice",
                               password="WrongPass1", known_hosts=None)
    except Exception:
        wrong = True
    check("S10 错误密码拒绝", wrong)

    async with asyncssh.connect("127.0.0.1", port=2022, username="bob",
                                password="Bob123456", known_hosts=None) as conn:
        async with conn.start_sftp_client() as sftp:
            async with sftp.open("/bob_secret.txt", "wb") as f:
                await f.write(b"bob data")
            names = await sftp.listdir("/")
            check("S11 bob 只见自己目录（列表隔离）",
                  "bob_secret.txt" in names and "alice" not in str(names).lower(), str(names))
            iso = False
            try:
                await sftp.stat("/../alice/dir1")
            except asyncssh.SFTPError:
                iso = True
            check("S12 bob 跨目录访问被拒", iso)


asyncio.run(sftp_checks())

# ================= 会话 / 审计 =================
r = c.get("/api/v1/sessions", headers=H)
check("M1 会话列表接口", r.status_code == 200, r.text[:80])
r = c.get("/api/v1/logs", params={"action": "login"}, headers=H)
check("M2 审计日志查询", r.status_code == 200 and r.json()["total"] > 0, r.text[:80])

# ================= Web 加密路径 =================
r = c.get("/api/v1/users", headers=H)
users = {u["username"]: u for u in r.json()}
alice, bob = users["alice"], users["bob"]
atok, bobtok = alice["web_token"], bob["web_token"]
check("W1 加密路径生成(20~24位)", bool(atok) and 20 <= len(atok) <= 24, f"{atok} len={len(atok)}")

r = c.post("/web/login", json={"username": "alice", "password": "bad"})
check("W2 Web 错误密码拒绝", r.status_code == 401)

r = c.post("/web/login", json={"username": "alice", "password": "Alice1234"})
check("W3 Web 登录", r.status_code == 200, str(r.status_code))

r = c.get(f"/f/{atok}/api/list", params={"path": "/"})
check("W4 加密路径文件列表", r.status_code == 200 and
      any(i["name"] == "dir1" for i in r.json().get("items", [])), r.text[:120])
check("W5 真实路径零暴露", alice["root_dir"] not in r.text)

r = c.post(f"/f/{atok}/upload", params={"path": "/"},
           files={"file": ("webup.txt", b"web-content-123", "text/plain")})
check("W6 Web 上传", r.status_code == 200, r.text[:80])
r = c.get(f"/f/{atok}/download", params={"path": "/webup.txt"})
check("W7 Web 下载内容一致", r.content == b"web-content-123")

r_noauth = httpx.Client(base_url=BASE).get(f"/f/{atok}/api/list", params={"path": "/"})
check("W8 未登录访问 401/404", r_noauth.status_code in (401, 404), str(r_noauth.status_code))

r = httpx.Client(base_url=BASE).get(f"/f/{bobtok}/api/list", params={"path": "/"})
check("W9 他人加密路径 404（不泄露存在性）", r.status_code == 404, str(r.status_code))

r = c.post(f"/f/{atok}/upload", params={"path": "/"},
           files={"file": ("big.bin", b"x" * (6 * 1024 * 1024), "application/octet-stream")})
check("W10 Web 上传超配额被拒(507)", r.status_code == 507, str(r.status_code))

r = c.post(f"/api/v1/users/{alice['id']}/regen-web-token", headers=H)
newtok = r.json().get("web_token", "")
check("W11 轮换加密路径", bool(newtok) and newtok != atok)
r = httpx.Client(base_url=BASE).get(f"/f/{atok}/api/list", params={"path": "/"})
check("W12 旧加密路径已失效", r.status_code == 404, str(r.status_code))

# 汇总
fails = [n for n, ok in results if not ok]
print("\n===== SUMMARY =====")
print(f"total={len(results)} pass={len(results) - len(fails)} fail={len(fails)}")
if fails:
    print("FAILED:", fails)
    sys.exit(1)
print("ALL TESTS PASSED")

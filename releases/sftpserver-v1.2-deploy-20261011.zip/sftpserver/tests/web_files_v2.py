# -*- coding: utf-8 -*-
"""Web 文件访问（加密路径）专项测试（自愈式：先重置账号到已知状态）"""
import io
import os
import sys

import httpx

BASE = "http://127.0.0.1:8443"
ROOT_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
results = []


def check(name, ok, detail=""):
    results.append((name, ok, detail))
    print(("PASS " if ok else "FAIL ") + name + ("  | " + str(detail) if detail and not ok else ""))


# ---------- 管理员准备环境 ----------
admin = httpx.Client(base_url=BASE, timeout=30)
H = {"Authorization": "Bearer " + admin.post("/api/v1/auth/login",
     json={"username": "admin", "password": "admin1234"}).json()["token"]}

users = {u["username"]: u for u in admin.get("/api/v1/users", headers=H).json()}
# 测试前置自愈：把三个账号重置到已知状态（密码/权限/配额/Web 开关）
WANT = {
    "alice": ("Alice1234", dict(perm_read=True, perm_write=True, perm_delete=True,
                                perm_rename=True, web_enabled=True, enabled=True,
                                quota_bytes=100 * 1024 * 1024)),
    "bob":   ("Bob123456", dict(perm_read=True, perm_write=True, perm_delete=False,
                                perm_rename=False, web_enabled=True, enabled=True,
                                quota_bytes=100 * 1024 * 1024)),
    "carol": ("Carol1234", dict(perm_read=True, perm_write=False, perm_delete=False,
                                perm_rename=False, web_enabled=True, enabled=True,
                                quota_bytes=100 * 1024 * 1024)),
}
for name, (pw, fields) in WANT.items():
    if name not in users:
        admin.post("/api/v1/users", json={"username": name, "password": pw}, headers=H)
    lst = admin.get("/api/v1/users", headers=H).json()
    uid = [x for x in lst if x["username"] == name][0]["id"]
    admin.post(f"/api/v1/users/{uid}/reset-password", json={"password": pw}, headers=H)
    admin.patch(f"/api/v1/users/{uid}", json=fields, headers=H)
users = {u["username"]: u for u in admin.get("/api/v1/users", headers=H).json()}
TOK = {n: users[n]["web_token"] for n in users}

# ---------- 1. 登录页与登录 ----------
r = admin.get("/web/login")
check("W-01 登录页可访问", r.status_code == 200 and "文件访问登录" in r.text)

c = httpx.Client(base_url=BASE, timeout=30)
r = c.post("/web/login", json={"username": "alice", "password": "wrong-pass"})
check("W-02 错误密码 401", r.status_code == 401)

r = c.post("/web/login", json={"username": "alice", "password": "Alice1234"})
tok_in_body = (r.text.split("/f/")[1].split("/")[0] if "/f/" in r.text else "")
check("W-03 登录成功且返回当前 token", r.status_code == 200 and tok_in_body == TOK["alice"],
      f"body_tok={tok_in_body} db_tok={TOK['alice']}")
check("W-04 会话 Cookie 已下发", "websess" in c.cookies)

# ---------- 2. 加密路径访问控制 ----------
r = httpx.Client(base_url=BASE).get(f"/f/{TOK['alice']}/api/list", params={"path": "/"})
check("W-05 未登录访问加密路径 404", r.status_code == 404, r.status_code)

r = c.get("/f/INVALIDTOKEN00000000000000/api/list", params={"path": "/"})
check("W-06 无效 token 404", r.status_code == 404, r.status_code)

r = c.get(f"/f/{TOK['bob']}/api/list", params={"path": "/"})
check("W-07 他人 token 404（不泄露存在性）", r.status_code == 404, r.status_code)

r = c.get(f"/f/{TOK['alice']}/")
check("W-08 加密路径首页 HTML 200", r.status_code == 200 and "文件列表" in r.text)

r = c.get(f"/f/{TOK['alice']}/api/list", params={"path": "/"})
check("W-09 目录列表 200", r.status_code == 200, r.text[:120])
names = [i["name"] for i in r.json().get("items", [])]
check("W-10 列表仅含本人文件（隔离）", "欢迎.txt" in names and "alice" not in names and "bob" not in names, names)

r = c.get(f"/f/{TOK['alice']}/api/list", params={"path": "/../../"})
check("W-11 相对越界 403", r.status_code == 403, r.status_code)
r = c.get(f"/f/{TOK['alice']}/api/list", params={"path": "/..\\..\\windows"})
check("W-12 反斜杠越界 403", r.status_code == 403, r.status_code)

# ---------- 3. 下载 ----------
r = c.get(f"/f/{TOK['alice']}/download", params={"path": "/欢迎.txt"})
check("W-13 下载文件 200 且内容正确", r.status_code == 200 and "欢迎" in r.content.decode("utf-8", "replace"),
      r.status_code)
r = c.get(f"/f/{TOK['alice']}/download", params={"path": "/不存在.txt"})
check("W-14 下载不存在文件 404", r.status_code == 404, r.status_code)
r = c.get(f"/f/{TOK['alice']}/download", params={"path": "/资料"})
check("W-15 下载目录被拒 404", r.status_code == 404, r.status_code)

# ---------- 4. 上传 / 删除 ----------
r = c.post(f"/f/{TOK['alice']}/upload", params={"path": "/"},
           files={"file": ("web测试.txt", io.BytesIO("web上传内容".encode()), "text/plain")})
check("W-16 上传到根目录 200", r.status_code == 200, r.text[:120])

r = c.post(f"/f/{TOK['alice']}/upload", params={"path": "/资料"},
           files={"file": ("子目录文件.txt", io.BytesIO(b"sub"), "text/plain")})
check("W-17 上传到子目录 200", r.status_code == 200, r.text[:120])

# 恶意文件名：basename 消毒后应落在本人目录内，绝不允许出现在根目录之外
outside = os.path.join(ROOT_HERE, "逃逸.txt")
outside2 = os.path.join(ROOT_HERE, "data", "files", "逃逸.txt")
for p in (outside, outside2):
    if os.path.exists(p):
        os.remove(p)
r = c.post(f"/f/{TOK['alice']}/upload", params={"path": "/"},
           files={"file": ("../逃逸.txt", io.BytesIO(b"x"), "text/plain")})
r2 = c.get(f"/f/{TOK['alice']}/api/list", params={"path": "/"})
inside = any("逃逸" in i["name"] for i in r2.json()["items"])
check("W-18 恶意文件名消毒（落在本人目录内、未逃出）",
      r.status_code == 200 and inside and not os.path.exists(outside) and not os.path.exists(outside2),
      f"status={r.status_code} inside={inside}")

r = c.post(f"/f/{TOK['alice']}/delete", params={"path": "/web测试.txt"})
check("W-19 删除自己文件 200", r.status_code == 200, r.text[:120])

# bob 无删除权限
cb = httpx.Client(base_url=BASE, timeout=30)
r = cb.post("/web/login", json={"username": "bob", "password": "Bob123456"})
check("W-20a bob 已知密码可登录", r.status_code == 200, r.status_code)
r = cb.post(f"/f/{TOK['bob']}/delete", params={"path": "/throttle.bin"})
check("W-20 bob 无删除权限被拒 403", r.status_code == 403, r.status_code)

# carol 无写入权限
cc = httpx.Client(base_url=BASE, timeout=30)
cc.post("/web/login", json={"username": "carol", "password": "Carol1234"})
r = cc.post(f"/f/{TOK['carol']}/upload", params={"path": "/"},
            files={"file": ("x.txt", io.BytesIO(b"x"), "text/plain")})
check("W-21 carol 只读上传被拒 403", r.status_code == 403, r.status_code)

# ---------- 5. 配额 ----------
r = admin.patch(f"/api/v1/users/{users['bob']['id']}",
                json={"quota_bytes": 1024}, headers=H)
big = b"B" * 2048
r = cb.post(f"/f/{TOK['bob']}/upload", params={"path": "/"},
            files={"file": ("big.bin", io.BytesIO(big), "application/octet-stream")})
check("W-22 超空间配额上传被拒 507", r.status_code == 507, r.status_code)
admin.patch(f"/api/v1/users/{users['bob']['id']}",
            json={"quota_bytes": 100 * 1024 * 1024}, headers=H)

# ---------- 6. 改名（PRD W 要求） ----------
c.post(f"/f/{TOK['alice']}/delete", params={"path": "/资料/改名后.txt"})  # 清理上轮残留
r = c.post(f"/f/{TOK['alice']}/rename", params={"path": "/资料/子目录文件.txt", "to": "/资料/改名后.txt"})
check("W-23 Web 改名接口", r.status_code == 200, f"status={r.status_code} body={r.text[:80]}")
r = c.get(f"/f/{TOK['alice']}/api/list", params={"path": "/资料"})
check("W-23a 改名后列表生效", r.status_code == 200 and
      any(i["name"] == "改名后.txt" for i in r.json()["items"]), r.text[:150])

# ---------- 7. 退出登录 ----------
r = c.post("/web/logout")
check("W-24 退出登录 200", r.status_code == 200)
r = c.get(f"/f/{TOK['alice']}/api/list", params={"path": "/"})
check("W-25 退出后访问 404", r.status_code == 404, r.status_code)

# ---------- 8. token 轮换与 Web 关闭 ----------
r = admin.post(f"/api/v1/users/{users['alice']['id']}/regen-web-token", headers=H)
new_tok = r.json().get("web_token", "")
check("W-26 轮换返回新 token", r.status_code == 200 and new_tok and new_tok != TOK["alice"],
      r.text[:120])

c2 = httpx.Client(base_url=BASE, timeout=30)
c2.post("/web/login", json={"username": "alice", "password": "Alice1234"})
r = c2.get(f"/f/{TOK['alice']}/api/list", params={"path": "/"})
check("W-27 旧 token 轮换后 404", r.status_code == 404, r.status_code)
r = c2.get(f"/f/{new_tok}/api/list", params={"path": "/"})
check("W-28 新 token 可用", r.status_code == 200, r.status_code)

r = admin.patch(f"/api/v1/users/{users['alice']['id']}", json={"web_enabled": False}, headers=H)
r = c2.get(f"/f/{new_tok}/api/list", params={"path": "/"})
check("W-29 关闭 Web 后 404", r.status_code == 404, r.status_code)
admin.patch(f"/api/v1/users/{users['alice']['id']}",
            json={"web_enabled": True}, headers=H)

# ---------- 汇总 ----------
fails = [x for x in results if not x[1]]
print(f"\n===== {len(results) - len(fails)}/{len(results)} 通过 =====")
for name, _, detail in fails:
    print("FAIL:", name, "|", detail)
sys.exit(0)

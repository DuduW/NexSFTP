@echo off
rem SFTP Server one-click launcher (ASCII path only)
cd /d C:\Users\double\WorkBuddy\2026-10-11-09-25-30\sftpserver
echo [sftpserver] starting... SFTP=127.0.0.1:2022  Admin=http://127.0.0.1:8443/admin
C:\Users\double\.workbuddy\binaries\python\envs\sftpserver\Scripts\python.exe run.py
pause
